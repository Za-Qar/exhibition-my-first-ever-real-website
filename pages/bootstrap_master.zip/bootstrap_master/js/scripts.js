
/* 
	Das hier schreibt man, damit sicher gestellt ist, das jQuery komplett geladen wurde
	und alle PlugIns für jQuery vorhanden sind. Sonst könnte es sein, dass man einen
	Befehl aufruft, der noch gar nicht geladen wurde!
*/


$(function () {
	
	/* Beispiel für die Aktivierung des Bootstrap Tooltip */
	
	$('[data-toggle="tooltip"]').tooltip();
	
});
